//<div id=14 class="technorati17_grey" onclick="switch_css17(14)"></div>


document.write('<scr'+'ipt type="text/javascript" src="http://columnasoft.com/posthis/js/cs_postthis1.0.js" ></scr'+'ipt>'); 



/* block for image begin */

 var spath;
 var spath2;
 var ver_Ma;
 var ver_mi;
 var scss_n = "background-color: #F5F5F5;";
 
 ver_Ma = img_ps.substring(0,5);
 ver_mi = img_ps.substring(5);

 if (ver_Ma == 'h17px'){

  switch(parseInt(ver_mi)){

  case 1:
    spath = "http://columnasoft.com/posthis/images/posthis17t_white.png";
    break;

  case 2:
    spath = "http://columnasoft.com/posthis/images/posthis17t_black.png";
    break;

  case 3:
    spath = "http://columnasoft.com/posthis/images/posthis17t_bw.png";
    break;

  case 4:
    spath = "http://columnasoft.com/posthis/images/posthis17_w.png";
    break;

  default:
    spath = "http://columnasoft.com/posthis/images/posthis17t_white.png";
  }

  //document.getElementById("post_i").src = spath ;

 }
 else if (ver_Ma == 'h32px'){

  switch(parseInt(ver_mi)){

  case 1:
    spath = "http://columnasoft.com/posthis/images/logo4_32.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17_w.png";
    break;

  case 2:
    spath = "http://columnasoft.com/posthis/images/posthis17t_black.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17_w.png";
    break;

  case 3:
    spath = "http://columnasoft.com/posthis/images/posthis17t_bw.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17_w.png";	
    break;

  case 4:
    spath = "http://columnasoft.com/posthis/images/posthis32_w.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17t_white.png";
    break;

  case 5:
    spath = "http://columnasoft.com/posthis/images/posthis17t_black.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17t_black.png";
    break;

  case 6:
    spath = "http://columnasoft.com/posthis/images/posthis17t_bw.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17t_bw.png";	
    break;

  case 7:
    spath = "http://columnasoft.com/posthis/images/posthis17t_white.png";    
    spath2 = "http://columnasoft.com/posthis/images/posthis17_w.png";
    break;

  case 8:
    spath = "http://columnasoft.com/posthis/images/posthis32t_w.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17_w.png";
    break;

  default:
    spath = "http://columnasoft.com/posthis/images/posthis17t_white.png";
    spath2 = "http://columnasoft.com/posthis/images/posthis17_w.png";
  }

  //document.getElementById("post_i").src = spath ;
  //document.getElementById("post_i2").src = spath2 ;

 }
 else if (ver_Ma == 'e32px'){

  switch(parseInt(ver_mi)){

  case 1:
    scss_n = "background-color: #F5F5F5;";
    spath = "http://columnasoft.com/posthis/images/logo4_32.png";
    break;

  case 2:
    scss_n = "background-color: transparent;";
    spath = "http://columnasoft.com/posthis/images/logo4_32.png";
    break;

  case 3:
    scss_n = "background-color: #F5F5F5;";
    spath = "http://columnasoft.com/posthis/images/posthis32t_w.png";
    break;

  case 4:
    scss_n = "background-color: transparent;";
    spath = "http://columnasoft.com/posthis/images/posthis32t_w.png";
    break;

  default:
    scss_n = "background-color: #F5F5F5;";
    spath = "http://columnasoft.com/posthis/images/posthis32t_w.png";
    

}}


var img_size=img_ps.substring(1);
var img_pos=img_ps.substring(0,1);
var pt_ver = img_ps.substring(0,5);

if (pt_ver=='v32px') {

document.write('<div id="headerDiv" style="display: block;">');

     document.write('<div id=1 class="facebook_grey_v32" onclick="switch_css_(1)"></div>');

     document.write('<div id=2 class="twitter_grey_v32" onclick="switch_css_(2)"></div>');

     document.write('<div id=3 class="linkedin_grey_v32" onclick="switch_css_(3)"></div>');

     document.write('<div id=4 class="google_grey_v32" onclick="switch_css_(4)"></div>');

     document.write('<div id=9 class="pinterest_grey_v32" onclick="switch_css_(9)"></div>');

     document.write('<div id="titleText"><a id="myHeader" href="javascript:toggle2(&#39;myContent&#39;,&#39;myHeader&#39;);" ><img src="http://columnasoft.com/posthis/images/plus.png" width="32" height="12"  /></a></div>');

     document.write('<div id="pt_logo" style="display:block;"><img id="post_i" src="http://columnasoft.com/posthis/images/posthis32_w.png" onclick="cs_postthis()" /></div>');

document.write('</div>');
document.write('<div style="clear:both;"></div>');

document.write('<div id="contentDiv">');

     document.write('<div id="myContent" style="display: none;">');

     document.write('<div id=5 class="digg_grey_v32" onclick="switch_css_(5)"></div>');

     document.write('<div id=6 class="reddit_grey_v32" onclick="switch_css_(6)"></div>');

     document.write('<div id=7 class="stumble_grey_v32" onclick="switch_css_(7)"></div>');
     document.write('<div id=16 class="socl_grey_v32" onclick="switch_css_(16)"></div>');

     document.write('<div id=10 class="delicious_grey_v32" onclick="switch_css_(10)"></div>');

     document.write('<div id=8 class="tumblr_grey_v32" onclick="switch_css_(8)"></div>');
     document.write('<div id=11 class="blogger_grey_v32" onclick="switch_css_(11)"></div>');
     document.write('<div id=12 class="wordpress_grey_v32" onclick="switch_css_(12)"></div>');

     document.write('<div id=15 class="email_grey_v32" onclick="switch_css_(15)"></div>');

     document.write('<div id=13 class="print_grey_v32" onclick="switch_css_(13)"></div>');

     document.write('<div id="chkb_v32"><input type="checkbox" id="isa" onclick="select_alld2(32)"/></div>');
     document.write('<div id="text_v32">select all</div>');
     document.write('<div id="titleText"><a id="myHeader" href="javascript:toggle2(&#39;myContent&#39;,&#39;myHeader&#39;);" ><img src="http://columnasoft.com/posthis/images/minus12-32.png" width="12" height="32"  /></a></div>');
     document.write('<div id="pt_logo_v" style="display:block;"><img src="http://columnasoft.com/posthis/images/posthis32_w.png" onclick="cs_postthis()"/></div>');  
document.write('</div>');

document.write('</div>');
}
else if (pt_ver=='p17px' ) {
document.write('<a href="javascript:;" onclick="toggle(&#39;one&#39;);"><img id="post_i" src="http://columnasoft.com/posthis/images/posthis17t_white.png"></a>');
document.write('<div id="one" style="display: none; position: absolute; width: 140px; height: 110px; background-color: rgb(245, 245, 245); box-shadow: -1px 1px 1px rgba(0, 0, 0, 0.05), 0pt 0pt 1px white inset; border-radius: 5px 5px 5px 5px; border-bottom: 1px solid rgb(204, 204, 204); border-left: 1px solid rgb(204, 204, 204);">');

     document.write('<div id=1 class="facebook_grey_p17" onclick="switch_css_(1)" ></div>');

     document.write('<div id=2 class="twitter_grey_p17" onclick="switch_css_(2)"></div>');

     document.write('<div id=3 class="linkedin_grey_p17" onclick="switch_css_(3)"></div>');

     document.write('<div id=4 class="google_grey_p17" onclick="switch_css_(4)"></div>');

     document.write('<div id=9 class="pinterest_grey_p17" onclick="switch_css_(9)"></div>');

     document.write('<div id=5 class="digg_grey_p17" onclick="switch_css_(5)"></div>');

     document.write('<div id=6 class="reddit_grey_p17" onclick="switch_css_(6)"></div>');

     document.write('<div id=7 class="stumble_grey_p17" onclick="switch_css_(7)"></div>');
     document.write('<div id=16 class="socl_grey_p17" onclick="switch_css_(16)"></div>');

     document.write('<div id=10 class="delicious_grey_p17" onclick="switch_css_(10)"></div>');

     document.write('<div id=8 class="tumblr_grey_p17" onclick="switch_css_(8)"></div>');

     document.write('<div id=12 class="wordpress_grey_p17" onclick="switch_css_(12)"></div>');

     document.write('<div id=11 class="blogger_grey_p17" onclick="switch_css_(11)"></div>');

     document.write('<div id=15 class="email_grey_p17" onclick="switch_css_(15)"></div>');

     document.write('<div id=13 class="print_grey_p17" onclick="switch_css_(13)"></div>');

     

    document.write('<div class="bottom"><div id="chkb_v17"><input id="isa" type="checkbox" onclick="select_alld2(17)"></div>');
    document.write('<div id="text_v17">select all</div>')

    document.write('<img src="http://columnasoft.com/posthis/images/posthis17_w.png" onclick="cs_postthis()"></div>');

document.write('</div>');
}

else if (pt_ver=='e32px' ){
document.write('<div id="headerDiv_e32" style="display: block;' + scss_n +'">');

     document.write('<div id=1 class="facebook_grey_e32" onclick="switch_css_(1)"></div>');

     document.write('<div id=2 class="twitter_grey_e32" onclick="switch_css_(2)"></div>');

     document.write('<div id=3 class="linkedin_grey_e32" onclick="switch_css_(3)"></div>');

     document.write('<div id=4 class="google_grey_e32" onclick="switch_css_(4)"></div>');

     document.write('<div id=9 class="pinterest_grey_e32" onclick="switch_css_(9)"></div>');

     document.write('<div id=5 class="digg_grey_e32" onclick="switch_css_(5)"></div>');

     document.write('<div id=6 class="reddit_grey_e32" onclick="switch_css_(6)"></div>');

     document.write('<div id=7 class="stumble_grey_e32" onclick="switch_css_(7)"></div>');

     document.write('<div id=16 class="socl_grey_e32" onclick="switch_css_(16)"></div>');

     document.write('<div id=10 class="delicious_grey_e32" onclick="switch_css_(10)"></div>');

     document.write('<div id=8 class="tumblr_grey_e32" onclick="switch_css_(8)"></div>');

     document.write('<div id=12 class="wordpress_grey_e32" onclick="switch_css_(12)"></div>');

     document.write('<div id=11 class="blogger_grey_e32" onclick="switch_css_(11)"></div>');

     document.write('<div id=15 class="email_grey_e32" onclick="switch_css_(15)"></div>');

     document.write('<div id=13 class="print_grey_e32" onclick="switch_css_(13)"></div>');

     document.write('<div id="chkb_e32"><input type="checkbox" id="isa" onclick="select_alld2(17)"/></div>');

     document.write('<div id="text_e32">select all</div>')
     document.write('<div id="pt_logo"><img id="post_i" src="' + spath + '" onclick="cs_postthis()" /></div>');

document.write('</div>');
}

else if (pt_ver=='h17px'){
document.write('<div id="headerDiv_H" style="display: block;">');
     document.write('<div id=1 class="facebook_grey_h17" onclick="switch_css_(1)"></div>');
     document.write('<div id=2 class="twitter_grey_h17" onclick="switch_css_(2)"></div>');
     document.write('<div id=3 class="linkedin_grey_h17" onclick="switch_css_(3)"></div>');
     document.write('<div id=4 class="google_grey_h17" onclick="switch_css_(4)"></div>');
     document.write('<div id=9 class="pinterest_grey_h17" onclick="switch_css_(9)"></div>');
     document.write('<div id="titleText_H"><a href="javascript:toggle3(&#39;one17&#39;,&#39;post&#39;);"><img src="http://columnasoft.com/posthis/images/plus_sm.png" width="14" height="12" /></a></div>');
     document.write('<div id="post" style="display:block;">');
     document.write('<img id="post_i" src="' + spath + '" width="76" height="17" align="absmiddle" onclick="cs_postthis()"/>');
     document.write('</div>');
document.write('<div id="one17">');
     document.write('<div id=5 class="digg_grey_h17" onclick="switch_css_(5)"></div>');
     document.write('<div id=6 class="reddit_grey_h17" onclick="switch_css_(6)"></div>');
     document.write('<div id=7 class="stumble_grey_h17" onclick="switch_css_(7)"></div>');
     document.write('<div id=16 class="socl_grey_h17" onclick="switch_css_(16)"></div>');
     document.write('<div id=10 class="delicious_grey_h17" onclick="switch_css_(10)"></div>');
     document.write('<div id=8 class="tumblr_grey_h17" onclick="switch_css_(8)"></div>');
     document.write('<div id=12 class="wordpress_grey_h17" onclick="switch_css_(12)"></div>');
     document.write('<div id=11 class="blogger_grey_h17" onclick="switch_css_(11)"></div>');
     document.write('<div id=15 class="email_grey_h17" onclick="switch_css_(15)"></div>');
     document.write('<div id=13 class="print_grey_h17" onclick="switch_css_(13)"></div>');
     document.write('<div class="bottom_sm"><div id="chkb_h17"><input type="checkbox" id="isa" onclick="select_alld2(17)"/></div>');
     document.write('<div id="text_h17">select all</div>');
    document.write('<img src="http://columnasoft.com/posthis/images/posthis17_w.png" onclick="cs_postthis()" />');
document.write('</div>');
document.write('</div>');
document.write('</div>');

}

else if (pt_ver=='h32px'){
document.write('<div id="headerDiv_H32" style="width=1200 height=42;">');
     document.write('<div id=1 class="facebook_grey_h32" onclick="switch_css_(1)"></div>');
     document.write('<div id=2 class="twitter_grey_h32" onclick="switch_css_(2)"></div>');
     document.write('<div id=3 class="linkedin_grey_h32" onclick="switch_css_(3)"></div>');
     document.write('<div id=4 class="google_grey_h32" onclick="switch_css_(4)"></div>');
     document.write('<div id=9 class="pinterest_grey_h32" onclick="switch_css_(9)"></div>');
     document.write('<div id="titleText_H32"><a href="javascript:toggle4(&#39;one32&#39;,&#39;post32&#39;);"><img src="http://columnasoft.com/posthis/images/plus_sm.png" width="14" height="12" /></a></div>');
     document.write('<div id="post32" style="width=76 height=42;">');
     document.write('<img id="post_i" src="' + spath + '" onclick="cs_postthis()"/></div>');
document.write('<div id="one32">');
     document.write('<div id=5 class="digg_grey_h32" onclick="switch_css_(5)"></div>');
     document.write('<div id=6 class="reddit_grey_h32" onclick="switch_css_(6)"></div>');
     document.write('<div id=7 class="stumble_grey_h32" onclick="switch_css_(7)"></div>');
     document.write('<div id=16 class="socl_grey_h32" onclick="switch_css_(16)"></div>');
     document.write('<div id=10 class="delicious_grey_h32" onclick="switch_css_(10)"></div>');
     document.write('<div id=8 class="tumblr_grey_h32" onclick="switch_css_(8)"></div>');
     document.write('<div id=12 class="wordpress_grey_h32" onclick="switch_css_(12)"></div>');
     document.write('<div id=11 class="blogger_grey_h32" onclick="switch_css_(11)"></div>');
     document.write('<div id=15 class="email_grey_h32" onclick="switch_css_(15)"></div>');
     document.write('<div id=13 class="print_grey_h32" onclick="switch_css_(13)"></div>');
     document.write('<div class="bottom_sm32"><div id="chkb_h32"><input type="checkbox" id="isa" onclick="select_alld2(17)" /></div>');
     document.write('<div id="text_h32">select all</div>');
     document.write('<img id="post_i2" src="' + spath2 + '" onclick="cs_postthis()" /></div>');
document.write('</div>');   
document.write('</div>');
}


//document.write('<scr'+'ipt type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" ></scr'+'ipt>');


/* block for image end */


var newwindow;
//if(document.getElementById('myContent').style.display != "none"){

//document.getElementById("isa").checked = false;
//}
if (pt_ver=='e32px'){
	document.getElementById("isa").checked = false;
}
else {
  if(document.getElementById('myContent')!= null && document.getElementById('myContent').style.display != "none"){
  document.getElementById("isa").checked = false;
}
 
}




var fb_1 = false;
var tw_2 = false;
var ld_3 = false;
var gp_4 = false;
var dg_5 = false;
var rd_6 = false;
var su_7 = false;
var pi_9 = false;
var tb_8 = false;
var de_10 =false;
var bg_11 =false;
var wp_12 =false;
var pr_13 =false;
var te_14 =false;
var em_15 = false;
var socl_16 = false;

function switch_image(i){


var cimg = document.getElementById(i);


switch (i)
{
case 1:

fb_1=!fb_1;
if(fb_1){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/facebook.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/facebook-grey.png";
}

break;

case 2:
tw_2=!tw_2;

if(tw_2){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/tw.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/tw-grey.png";
}
break;

case 3:
ld_3=!ld_3;
if(ld_3){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/linkedin.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/linkedin-grey.png";
}
break;

case 4:
gp_4=!gp_4;
if(gp_4){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/google.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/google-grey.png";
}
break;

case 5:
dg_5=!dg_5;
if(dg_5){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/digg.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/digg-grey.png";
}
break;

case 6:
rd_6=!rd_6;
if(rd_6){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/reddit.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/reddit-grey.png";
}
break;

case 7:
su_7=!su_7;
if(su_7){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/stumble.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/stumble-grey.png";
}

break;

case 8:
tb_8=!tb_8;
if(tb_8){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/tumblr.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/tumblr-grey.png";
}
break;

case 9:
pi_9=!pi_9;
if(pi_9){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/pinterest.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/pinterest-grey.png";
}
break;

case 10:
de_10=!de_10;
if(de_10){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/delicious.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/delicious-grey.png";
}
break;

case 11:
bg_11=!bg_11;
if(bg_11){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/blogger.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/blogger-grey.png";
}
break;

case 12:
wp_12=!wp_12;
if(wp_12){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/wordpress.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/wordpress-grey.png";
}
break;

case 13:
pr_13=!pr_13;
if(pr_13){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/print.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/print-grey.png";
}
break;

case 14:
te_14=!te_14;
if(te_14){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/technorati.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/technorati-grey.png";
}
break;

case 15:
em_15=!em_15;
if(em_15){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/email.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/email-grey.png";
}
break;


case 16:
socl_16=!socl_16;
if(socl_16){
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/socl.png";
}
else
{
cimg.src= "http://columnasoft.com/posthis/images/sntw/icons"+img_size+"/socl-grey.png";
}
break;

}
}



function cs_postthis(){

var burl = window.location.href; //document.URL;

burl = cs_escape(burl);

var btitle = document.title;

var mdesc = getMetaDescription();

var mogimage = getMetaOGImages()[0];

mogimage = cs_escape(mogimage);

var mogsitename = getMetaOGSiteName()

var pwindow;
var swindow;

if (em_15)
{
  var mailto_link = 'mailto:?subject='+document.title + '&body=I thought it may interest you: %0D' + burl + '%0D (via posthis)';
  win = window.open(mailto_link,'tempWindow');
  //if (win && win.open &&!win.closed) win.close();
}

//if (te_14){
//window.open('http://technorati.com/favs/?add=' + burl ,'te_post','height=400,width=520, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes'); }

if (socl_16){
window.open('http://www.so.cl/#/search?v=results&bk=1.0&q=' + burl ,'socl_post','height=600,width=1020, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}


if (wp_12){
//burl = cs_escape('http://www.forces.ca/en/home/');
var qs = 'u=' + burl + '&t=' + btitle + '&i=' + mogimage;
window.location="posthis/posthis_wp.html?" + qs;
//window.open("postthis_wp.html?" + qs);
//window.open("http://columnasoft.com/blog/wp-admin/press-this.php?u=http%3A%2F%2Fwww.forces.ca%2Fen%2Fhome%2F%23.T5gGl9CtpOE.wordpress&t=FORCES.CA+-+Home&s=&v=2");
}

if (bg_11){
//burl = 'http://www.forces.ca/en/home/
window.open('http://www.blogger.com/blog-this.g?t&u=' + burl + '&n=' + btitle,'bg_post','height=530,width=470, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}

if (tb_8){
window.open('http://www.tumblr.com/share/link?url=' + burl + '&name=' + btitle + '&description=' + mdesc,'tb_post','height=440,width=610, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}

if (de_10){
//burl = 'http://www.forces.ca/en/home/';
window.open('http://delicious.com/post?url=' + burl + '&title=' + btitle + '&notes=' + mdesc, 'de_post','height=570,width=700, left=0, top=0,resizable=yes,scrollbars=no,toolbar=yes,status=yes');
}


if (su_7){
window.open('http://www.stumbleupon.com/submit?url=' + burl + '&title=' + btitle,'su_post','height=600,width=800, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}

if (rd_6){
//verify subtmit comment
window.open('http://reddit.com/submit?url=' + burl + '&title=' + btitle,'rd_post','height=640,width=780, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}


if (dg_5){
//window.open('http://digg.com/submit?partner=addthis&url=' + burl + '&title=' + btitle + '&bodytext=testbodytext' + '&medium=' + mogimage + '&description=ssss'); 
//window.open('http://digg.com/submit?partner=addthis&url=http://news.cnet.com/8301-1035_3-57412750-94/dropping-instagram-already-try-these-android-alternatives/');

window.open('http://digg.com/submit?partner=addthis&url=' + burl + '&title=' + btitle + '&topic=', 'dg_post','height=740,width=700, left=0, top=0,resizable=yes,scrollbars=no,toolbar=yes,status=yes');
}

if (pi_9){
window.open('http://pinterest.com/pin/create/button/?url=' + burl + '&media=' + mogimage +  '&description=' + mdesc,'pi_post','height=360,width=580, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}

if (gp_4){
//burl = 'http://www.forces.ca/en/home/';
window.open('http://plus.google.com/share?url=' + burl + '&t=' + btitle,'gp_post','height=500,width=400,left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');

}

if (ld_3){
window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + burl + '&title=' + btitle + '&summary='+ mdesc +'&source=' + mogsitename, 'ld_post','height=420,width=560, left=0, top=0,resizable=yes,scrollbars=no,toolbar=yes,status=yes');
}

if (tw_2) {
swindow= window.open('https://twitter.com/share?url=' + burl + '&via=columnasoft','tw_post','height=420,width=550, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}

if (fb_1){
window.open('https://www.facebook.com/sharer/sharer.php?u=' + burl + '&t=title','fb_post','height=400,width=500, left=0, top=0,resizable=yes,scrollbars=yes,toolbar=yes,status=yes');
}

if (pr_13){
window.print();
}

}


function getMetaContent(attrtype, attrvalue) {
  
  var metas = document.getElementsByTagName('META');
  var i;
  var attrib;	
  var j;	
  var attribcontent;	
  
  for (i = 0; i < metas.length; i++){
    for (j=0; j< metas[i].attributes.length; j++){
       if (metas[i].attributes.item(j) == attrtype){
          if (metas[i].attributes.item(j).getAttribute(attrtype) == attrvalue){

          attrib = metas[i].attributes.item(j);
	  attribcontent = attrib.getAttribute('CONTENT');
	
	  break;  
         }
       }
     }
   }	
	

  //alert(attribcontent);

}


function getMetaDescription() {
    var VarContent='';
try{    
  var metas = document.getElementsByTagName('META');
  var i;
  for (i = 0; i < metas.length; i++)
    if (metas[i].getAttribute('NAME') == "description")
      break;
  VarContent = metas[i].getAttribute('CONTENT');
}
catch (err){}
  return VarContent;	
}

function getMetaOGImages() {

  var metas = document.getElementsByTagName('META');
  var ogImages = new Array(10);

  var i;
  var j=0;
try{
 for (i = 0; i < metas.length; i++){
    if (metas[i].getAttribute('property') == "og:image"){
	ogImages[j] = metas[i].getAttribute('CONTENT');
	j++;
    } 
  }
  
}
catch (err){}
  
  return ogImages;	
}

function getMetaOGSiteName() {
  var metas = document.getElementsByTagName('META');
  var i;
  var VarContent = '';
try{
  for (i = 0; i < metas.length; i++)
    if (metas[i].getAttribute('property') == "og:site_name")
      break;
  var VarContent = metas[i].getAttribute('CONTENT');
}
catch (err){}
  return VarContent;	
}

function select_all(){

	var v = document.getElementById("isa").value;

	if (document.getElementById("isa").checked){
		 fb_1 = false;
		 tw_2 = false;
		 ld_3 = false;
		 gp_4 = false;
		 dg_5 = false;
		 rd_6 = false;
		 su_7 = false;
		 pi_9 = false;
		 tb_8 = false;
		 de_10 =false;
		 bg_11 =false;
		 wp_12 =false;
		 pr_13 =false;
		 //te_14 =false;
		 em_15=false;
		 socl_16=false;
	}
	else{
		 fb_1 = true;
		 tw_2 = true;
		 ld_3 = true;
		 gp_4 = true;
		 dg_5 = true;
		 rd_6 = true;
		 su_7 = true;
		 pi_9 = true;
		 tb_8 = true;
		 de_10 =true;
		 bg_11 =true;
		 wp_12 =true;
		 pr_13 =true;
		 //te_14 =true;
		 em_15=true;
		 socl_16=true;
	}

	for(var i=0;i<=16;i++){
		switch_image(i);
	}
	

}

function toggle2(showHideDiv, switchTextDiv) {

	var ele = document.getElementById(showHideDiv);

	var text = document.getElementById(switchTextDiv);

	if(ele.style.display == "none") {

    		ele.style.display = "block";

			text.innerHTML = '' ;

			document.getElementById("pt_logo").style.display = "none";
			document.getElementById("isa").checked = false;

			

	}

	else {

		ele.style.display = "none";

		document.getElementById("pt_logo").style.display = "block";

		text.innerHTML = '<img style="border: none;" src="http://columnasoft.com/posthis/images/plus.png"/>';

	}

}

function toggle3(showHideDiv, switchTextDiv) {

	var ele = document.getElementById(showHideDiv);

	var text = document.getElementById(switchTextDiv);

	if(ele.style.display == "none") {

    		ele.style.display = "block";

			text.innerHTML = '' ;

			document.getElementById("post").style.display = "none";

			

	}

	else {

		ele.style.display = "none";

		document.getElementById("post").style.display = "block";

		//text.innerHTML = '<img style="border: none;" src="http://columnasoft.com/posthis/images/posthis17t_white2.png"/>';
		text.innerHTML = '<img style="border: none;" src="' + spath + '" onclick="cs_postthis()"/>';

	}

}


function toggle4(showHideDiv, switchTextDiv) {

	var ele = document.getElementById(showHideDiv);

	var text = document.getElementById(switchTextDiv);

	if(ele.style.display == "none") {

    		ele.style.display = "block";

			text.innerHTML = '' ;

			document.getElementById("post32").style.display = "none";

			

	}

	else {

		ele.style.display = "none";

		document.getElementById("post32").style.display = "block";

		//text.innerHTML = '<img style="border: none;" src="http://columnasoft.com/posthis/images/posthis17t_white2.png"/>';
		text.innerHTML = '<img style="border: none;" src="' + spath +'" onclick="cs_postthis()" />';

	}

}



function switch_css(i){


var cdiv = document.getElementById(i);


switch (i)
{
case 1:

fb_1=!fb_1;
if(fb_1){
//cdiv.className= "http://columnasoft.com/posthis/images/sntw/icons32px/facebook.png";
cdiv.className= "facebook";
}
else
{
cdiv.className= "facebook_grey";
}

break

case 2:
tw_2=!tw_2;

if(tw_2){
cdiv.className= "twitter";
}
else
{
cdiv.className= "twitter_grey";
}
break;

case 3:
ld_3=!ld_3;
if(ld_3){
cdiv.className= "linkedin";
}
else
{
cdiv.className= "linkedin_grey";
}
break;

case 4:
gp_4=!gp_4;
if(gp_4){
cdiv.className= "google";
}
else
{
cdiv.className= "google_grey";
}
break;

case 5:
dg_5=!dg_5;
if(dg_5){
cdiv.className= "digg";
}
else
{
cdiv.className= "digg_grey";
}
break;

case 6:
rd_6=!rd_6;
if(rd_6){
cdiv.className= "reddit";
}
else
{
cdiv.className= "reddit_grey";
}
break;

case 7:
su_7=!su_7;
if(su_7){
cdiv.className= "stumble";
}
else
{
cdiv.className= "stumble_grey";
}

break;

case 8:
tb_8=!tb_8;
if(tb_8){
cdiv.className= "tumblr";
}
else
{
cdiv.className= "tumblr_grey";
}
break;

case 9:
pi_9=!pi_9;
if(pi_9){
cdiv.className= "pinterest";
}
else
{
cdiv.className= "pinterest_grey";
}
break;

case 10:
de_10=!de_10;
if(de_10){
cdiv.className= "delicious";
}
else
{
cdiv.className= "delicious_grey";
}
break;

case 11:
bg_11=!bg_11;
if(bg_11){
cdiv.className= "blogger";
}
else
{
cdiv.className= "blogger_grey";
}
break;

case 12:
wp_12=!wp_12;
if(wp_12){
cdiv.className= "wordpress";
}
else
{
cdiv.className= "wordpress_grey";
}
break;

case 13:
pr_13=!pr_13;
if(pr_13){
cdiv.className= "print";
}
else
{
cdiv.className= "print_grey";
}
break;

/*
//case 14:
//te_14=!te_14;
//if(te_14){
//cdiv.className= "technorati";
//}
//else{
//cdiv.className= "technorati_grey";
//}
//break;
*/

case 15:
em_15=!em_15;
if(em_15){
cdiv.className= "email";
}
else
{
cdiv.className= "email_grey";
}
break;

case 16:
socl_16=!socl_16;
if(socl_16){
cdiv.className= "socl";
}
else
{
cdiv.className= "socl_grey";
}
break;

}
}

function select_alld(isize){

	var v = document.getElementById("isa").value;

	if (document.getElementById("isa").checked){
		 fb_1 = false;
		 tw_2 = false;
		 ld_3 = false;
		 gp_4 = false;
		 dg_5 = false;
		 rd_6 = false;
		 su_7 = false;
		 pi_9 = false;
		 tb_8 = false;
		 de_10 =false;
		 bg_11 =false;
		 wp_12 =false;
		 pr_13 =false;
		 te_14 =false;
		 em_15=false;
		 socl_16=false;
	}
	else{
		 fb_1 = true;
		 tw_2 = true;
		 ld_3 = true;
		 gp_4 = true;
		 dg_5 = true;
		 rd_6 = true;
		 su_7 = true;
		 pi_9 = true;
		 tb_8 = true;
		 de_10 =true;
		 bg_11 =true;
		 wp_12 =true;
		 pr_13 =true;
		 te_14 =true;
		 em_15=true;
		 socl_16=true;
	}

	if (isize==32){
		for(var i=0;i<=16;i++){
		switch_css(i);
		}
	}

	if (isize==17){
		for(var i=0;i<=16;i++){
		switch_css17(i);
		}
	}
	

}

/* class 17 */

function toggle(d)

{

	var o=document.getElementById(d);

	o.style.display=(o.style.display=='none')?'block':'none';
}

function switch_css17(i){


var cdiv = document.getElementById(i);


switch (i)
{
case 1:

fb_1=!fb_1;
if(fb_1){

cdiv.className= "facebook17";
}
else
{
cdiv.className= "facebook17_grey";
}

break

case 2:
tw_2=!tw_2;

if(tw_2){
cdiv.className= "twitter17";
}
else
{
cdiv.className= "twitter17_grey";
}
break;

case 3:
ld_3=!ld_3;
if(ld_3){
cdiv.className= "linkedin17";
}
else
{
cdiv.className= "linkedin17_grey";
}
break;

case 4:
gp_4=!gp_4;
if(gp_4){
cdiv.className= "google17";
}
else
{
cdiv.className= "google17_grey";
}
break;

case 5:
dg_5=!dg_5;
if(dg_5){
cdiv.className= "digg17";
}
else
{
cdiv.className= "digg17_grey";
}
break;

case 6:
rd_6=!rd_6;
if(rd_6){
cdiv.className= "reddit17";
}
else
{
cdiv.className= "reddit17_grey";
}
break;

case 7:
su_7=!su_7;
if(su_7){
cdiv.className= "stumble17";
}
else
{
cdiv.className= "stumble17_grey";
}

break;

case 8:
tb_8=!tb_8;
if(tb_8){
cdiv.className= "tumblr17";
}
else
{
cdiv.className= "tumblr17_grey";
}
break;

case 9:
pi_9=!pi_9;
if(pi_9){
cdiv.className= "pinterest17";
}
else
{
cdiv.className= "pinterest17_grey";
}
break;

case 10:
de_10=!de_10;
if(de_10){
cdiv.className= "delicious17";
}
else
{
cdiv.className= "delicious17_grey";
}
break;

case 11:
bg_11=!bg_11;
if(bg_11){
cdiv.className= "blogger17";
}
else
{
cdiv.className= "blogger17_grey";
}
break;

case 12:
wp_12=!wp_12;
if(wp_12){
cdiv.className= "wordpress17";
}
else
{
cdiv.className= "wordpress17_grey";
}
break;

case 13:
pr_13=!pr_13;
if(pr_13){
cdiv.className= "print17";
}
else
{
cdiv.className= "print17_grey";
}
break;

//case 14:
//te_14=!te_14;
//if(te_14){
//cdiv.className= "technorati17"; }
//else {
//cdiv.className= "technorati17_grey"; }
//break;

case 15:
em_15=!em_15;
if(em_15){
cdiv.className= "email17";
}
else
{
cdiv.className= "email17_grey";
}
break;

case 16:
socl_16=!socl_16;
if(socl_16){
cdiv.className= "socl17";
}
else
{
cdiv.className= "socl17_grey";
}
break;

}
}



function switch_css_(i){


var cdiv = document.getElementById(i);

var lst = "_" + img_ps.substring(0,3);


switch (i)
{
case 1:

fb_1=!fb_1;
if(fb_1){

cdiv.className= "facebook" + lst;
}
else
{
cdiv.className= "facebook_grey" + lst;
}

break

case 2:
tw_2=!tw_2;

if(tw_2){
cdiv.className= "twitter" + lst;
}
else
{
cdiv.className= "twitter_grey" + lst;
}
break;

case 3:
ld_3=!ld_3;
if(ld_3){
cdiv.className= "linkedin" + lst;
}
else
{
cdiv.className= "linkedin_grey" + lst;
}
break;

case 4:
gp_4=!gp_4;
if(gp_4){
cdiv.className= "google" + lst;
}
else
{
cdiv.className= "google_grey" + lst;
}
break;

case 5:
dg_5=!dg_5;
if(dg_5){
cdiv.className= "digg" + lst;
}
else
{
cdiv.className= "digg_grey" + lst;
}
break;

case 6:
rd_6=!rd_6;
if(rd_6){
cdiv.className= "reddit" + lst;
}
else
{
cdiv.className= "reddit_grey" + lst;
}
break;

case 7:
su_7=!su_7;
if(su_7){
cdiv.className= "stumble" + lst;
}
else
{
cdiv.className= "stumble_grey" + lst;
}

break;

case 8:
tb_8=!tb_8;
if(tb_8){
cdiv.className= "tumblr" + lst;
}
else
{
cdiv.className= "tumblr_grey" + lst;
}
break;

case 9:
pi_9=!pi_9;
if(pi_9){
cdiv.className= "pinterest" + lst;
}
else
{
cdiv.className= "pinterest_grey" + lst;
}
break;

case 10:
de_10=!de_10;
if(de_10){
cdiv.className= "delicious" + lst;
}
else
{
cdiv.className= "delicious_grey" + lst;
}
break;

case 11:
bg_11=!bg_11;
if(bg_11){
cdiv.className= "blogger" + lst;
}
else
{
cdiv.className= "blogger_grey" + lst;
}
break;

case 12:
wp_12=!wp_12;
if(wp_12){
cdiv.className= "wordpress" + lst;
}
else
{
cdiv.className= "wordpress_grey" + lst;
}
break;

case 13:
pr_13=!pr_13;
if(pr_13){
cdiv.className= "print" + lst;
}
else
{
cdiv.className= "print_grey" + lst;
}
break;

/*
//case 14:
//te_14=!te_14;
//if(te_14){
//cdiv.className= "technorati" + lst;
//}
//else{
//cdiv.className= "technorati_grey" + lst;
//}
//break;
*/

case 15:
em_15=!em_15;
if(em_15){
cdiv.className= "email" + lst;
}
else
{
cdiv.className= "email_grey" + lst;
}
break;

case 16:
socl_16=!socl_16;
if(socl_16){
cdiv.className= "socl" + lst;
}
else
{
cdiv.className= "socl_grey" + lst;
}
break;

}
}

function select_alld2(isize){

	var v = document.getElementById("isa").value;

	if (document.getElementById("isa").checked){
		 fb_1 = false;
		 tw_2 = false;
		 ld_3 = false;
		 gp_4 = false;
		 dg_5 = false;
		 rd_6 = false;
		 su_7 = false;
		 pi_9 = false;
		 tb_8 = false;
		 de_10 =false;
		 bg_11 =false;
		 wp_12 =false;
		 pr_13 =false;
		 te_14 =false;
		 em_15=false;
		 socl_16=false;
	}
	else{
		 fb_1 = true;
		 tw_2 = true;
		 ld_3 = true;
		 gp_4 = true;
		 dg_5 = true;
		 rd_6 = true;
		 su_7 = true;
		 pi_9 = true;
		 tb_8 = true;
		 de_10 =true;
		 bg_11 =true;
		 wp_12 =true;
		 pr_13 =true;
		 te_14 =true;
		 em_15=true;
		 socl_16=true;
	}

	if (isize==32){
		for(var i=0;i<=16;i++){
		switch_css_(i);
		}
	}

	if (isize==17){
		for(var i=0;i<=16;i++){
		switch_css_(i);
		}
	}
	

}


function s_pt(img_psv){
 
 var spath;
 var ver_Ma;
 var ver_mi;
 
 ver_Ma = img_ps.substring(0,4);
 ver_mi = img_ps.substring(4,5);

 if (ver_Ma == 'h17px'){

  switch(ver_mi){

  case 1:
    spath = "images/posthis17t_white.png";
    break;

  case 2:
    spath = "images/posthis17t_black.png";
    break;

  case 3:
    spath = "images/posthis17t_bw.png";
    break;

  }

 }

 return spath;

}