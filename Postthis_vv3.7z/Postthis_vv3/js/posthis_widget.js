
<!-- posthis BEGIN -->
<div>
        <p> 
	
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/facebook-grey.png" width="32" height="32" id=1 onclick="switch_image(1)" alt="Share to Facebook"/></a>	       
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/tw-grey.png" width="32" height="32" id=2 onclick="switch_image(2)" alt="Tweet it"/></a>	
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/linkedin-grey.png" width="32" height="32" id=3 onclick="switch_image(3)" alt="Post on Linkedin" /></a>	  
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/google-grey.png" width="32" height="32" style="border:0;width:32px;height:32px;" id=4 onclick="switch_image(4)" alt="Publicly recommend on Google"/></a>	    
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/digg-grey.png" width="32" height="32" id=5 onclick="switch_image(5)" alt="Digg This"/>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/reddit-grey.png" width="32" height="32" id=6 onclick="switch_image(6)" alt="Send to Reddit"/></a>	   
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/stumble-grey.png" width="32" height="32" id=7 onclick="switch_image(7)" alt="Send to StumbleUpon"/></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/pinterest-grey.png" width="32" height="32" id=9 onclick="switch_image(9)" alt="Pin it" /></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/delicious-grey.png" width="32" height="32" id=10 onclick="switch_image(10)" alt="Collect it on Delicious"/></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/technorati-grey.png" width="32" height="32" id=14 onclick="switch_image(14)" alt="Bookmark it on Tecchnorati"/></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/tumblr-grey.png" width="32" height="32" id=8 onclick="switch_image(8)" alt="Share it on tumblr."/></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/blogger-grey.png" width="32" height="32" id=11 onclick="switch_image(11)" alt="Blog it on Blogger" /></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/wordpress-grey.png" width="32" height="32" id=12 onclick="switch_image(12)" alt="Publish it on WordPress" /></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/email-grey.png" width="32" height="32" id=15 onclick="switch_image(15)" alt="Print it"/></a>
	<img src="http://columnasoft.com/posthis/images/sntw/icons32px/print-grey.png" width="32" height="32" id=13 onclick="switch_image(13)" alt="Print it"/></a>

	<input type="checkbox" name="sa" value="sa" id="isa" onclick="select_all()"/> Select all
	<img src="http://columnasoft.com/posthis/images/logo4.png" width="32" height="32" id=17 onclick="cs_postthis()" alt="Posthis"/>

        </p>
</div>

<script type="text/javascript"> var img_size='32px';</script>
<script id="scrip" type="text/javascript" src="http://columnasoft.com/posthis/js/posthis.js"></script>

<!-- posthis END -->